import React, { useState, useEffect, useRef } from "react";
import {
  Grid,
  TextField,
  Autocomplete,
  Typography,
  Button,
} from "@mui/material";
import { FiDownload } from "react-icons/fi";

import html2canvas from "html2canvas";
import { saveAs } from "file-saver";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import axiosInstance from "../../../../api/axiosInstance";

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import dayjs from "dayjs";

import CircularProgress from "../../../component/loader";
const Example = () => {
  const [filterValue, setFilterValue] = useState({
    sites: null,
    device: null,
    sensor: null,
  });
  const [resFilterData, setResFilterData] = useState({
    respSites: null,
    respDevice: null,
    respSensor: null,
  });

  const [startDate, setStartDate] = useState();
  const [endDate, setEndDate] = useState();
  const [graphValue, setGraphValue] = useState(null);
  const [loading, setLoading] = useState(false);
  const handleFiterSelection = (event, value, field) => {
    setFilterValue((prevState) => ({
      ...prevState,
      [field]: value,
    }));
  };
  const handleData = (data, datatype) => {
    if (datatype == "startDate") {
      setStartDate(data);
    } else if (datatype == "endDate") {
      setEndDate(data);
    }
  };
  const getAllSites = async () => {
    try {
      const response = await axiosInstance.get(
        `api/site/searchSite?searchQuery`
      );
      const newSites = response.data.msg;
      setResFilterData((prevData) => ({
        ...prevData,
        respSites: newSites,
      }));
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const getAllDeviceBySiteId = async () => {
    try {
      const response = await axiosInstance.get(
        `/api/device/getdeviceListbysiteId/${siteId}`
      );
      const newDevices = response.data.msg;
      setResFilterData((prevData) => ({
        ...prevData,
        respDevice: newDevices,
      }));
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const defaultSiteValue = resFilterData?.respSites
    ? resFilterData?.respSites[0]
    : null;
  const defaultDeviceValue = resFilterData?.respDevice
    ? resFilterData?.respDevice[0]
    : null;
  const defaultSensorValue = resFilterData?.respSensor
    ? resFilterData?.respSensor[0]
    : null;

  const siteId = filterValue?.sites?._id ?? defaultSiteValue?._id;
  const filterDeviceId = filterValue?.device?._id ?? defaultDeviceValue?._id;
  const sensorName = filterValue?.sensor?._id ?? defaultSensorValue?._id;

  const getAllSensorBySiteDeviceId = async () => {
    try {
      const response = await axiosInstance.get(
        `/api/site/getSiteOrDeviceOrSensor/?siteId=${siteId}&deviceId=${filterDeviceId}`
      );
      const newDevices = response.data?.data;
      setResFilterData((prevData) => ({
        ...prevData,
        respSensor: newDevices,
      }));
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  const currentDate = dayjs().toDate();
  const graphData = graphValue?.data?.map((entry) => ({
    dateTime: dayjs(entry?.createdAt).format("DD-MM-YYYY h:mm A"),
    value: parseFloat(entry.alarmValue),
  }));
  const getAlarmGraphValue = async () => {
    const params = {
      deviceId: filterDeviceId,
      startDate: dayjs(startDate ? startDate : currentDate)
        .startOf("day")
        .format("YYYY-MM-DD"),
      endDate: dayjs(endDate ? endDate : currentDate)
        .endOf("day")
        .format("YYYY-MM-DD"),
      sensorName: sensorName,
    };
    try {
      setLoading(true);
      const response = await axiosInstance.get(
        `/api/alarm/getAlarmGraphValue`,
        {
          params,
        }
      );
      if (response.data) {
        setGraphValue(response.data);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    getAllSites();
  }, []);
  useEffect(() => {
    if (siteId) {
      getAllDeviceBySiteId();
    }
  }, [siteId]);

  useEffect(() => {
    if (siteId && filterDeviceId) {
      getAllSensorBySiteDeviceId();
    }
  }, [siteId, filterDeviceId]);

  useEffect(() => {
    if (filterDeviceId || startDate || endDate || sensorName) {
      getAlarmGraphValue();
      const intervalId = setInterval(() => {
        getAlarmGraphValue();
      }, 10000);
      return () => clearInterval(intervalId);
    }
  }, [sensorName, filterDeviceId, endDate, startDate]);

  const CustomXAxisTick = ({ x, y, payload }) => {
    const dateTimeParts = payload.value.split(" ");

    return (
      <g transform={`translate(${x},${y})`}>
        <text x={0} y={0} dy={16} textAnchor="middle" fill="#666">
          {dateTimeParts[0]}
        </text>
        <text x={0} y={16} dy={16} textAnchor="middle" fill="#666">
          {dateTimeParts[1]}
        </text>
      </g>
    );
  };
  const handleScreenshotDownload = async () => {
    const container = document.getElementById("graphContainer");
    try {
      const canvas = await html2canvas(container);
      // Convert canvas to base64 URL
      const base64Image = canvas.toDataURL("image/png");
      saveAs(base64Image, "graphScreenshot.png");
    } catch (error) {
      console.error("Error taking screenshot:", error);
    }
  };

  return (
    <>
      <Grid container id="graphContainer">
        <Typography variant="h6" className="heading-black">
          Manage Alarm
        </Typography>
        <Grid
          container
          mt={3}
          direction="row"
          alignItems="center"
          justifyContent={"space-between"}
        >
          <Grid item xs={4.5}>
            <Grid container spacing={2}>
              <Grid item xs={4}>
                <Autocomplete
                  className="autocompletestyle"
                  disablePortal
                  id="combo-box-demo"
                  options={resFilterData?.respSites}
                  getOptionLabel={(option) => option.siteName}
                  value={filterValue?.sites || defaultSiteValue}
                  onChange={(event, value) =>
                    handleFiterSelection(event, value, "sites")
                  }
                  getOptionSelected={(option, value) =>
                    option.siteName === value
                  }
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="All Site"
                      sx={{
                        ".MuiAutocomplete-endAdornment .MuiAutocomplete-clearIndicator":
                          {
                            display: "none",
                          },
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item md={4}>
                <Autocomplete
                  className="autocompletestyle"
                  disablePortal
                  id="combo-box-demo-device"
                  options={resFilterData?.respDevice}
                  disabled={!resFilterData.respDevice}
                  getOptionLabel={(option) =>
                    option.deviceName || "Unknown Device"
                  }
                  value={filterValue?.device || defaultDeviceValue}
                  onChange={(event, value) =>
                    handleFiterSelection(event, value, "device")
                  }
                  getOptionSelected={(option, value) =>
                    option.deviceName === value
                  }
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      disabled={!resFilterData.respDevice}
                      label="All Devices"
                      sx={{
                        ".MuiAutocomplete-endAdornment .MuiAutocomplete-clearIndicator":
                          {
                            display: "none",
                          },
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item md={4}>
                <Autocomplete
                  className="autocompletestyle"
                  disablePortal
                  id="combo-box-demo-device"
                  options={resFilterData?.respSensor}
                  disabled={!resFilterData.respSensor}
                  getOptionLabel={(option) => option._id || "Unknown Device"}
                  value={filterValue?.sensor || defaultSensorValue}
                  onChange={(event, value) =>
                    handleFiterSelection(event, value, "sensor")
                  }
                  getOptionSelected={(option, value) => option._id === value}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      disabled={!resFilterData.respSensor}
                      label="All Sensor"
                      sx={{
                        ".MuiAutocomplete-endAdornment .MuiAutocomplete-clearIndicator":
                          {
                            display: "none",
                          },
                      }}
                    />
                  )}
                />
              </Grid>
            </Grid>
          </Grid>{" "}
          <Grid item xs={6}>
            <Grid container justifyContent={"flex-end"}>
              <Grid item xs={3}>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DatePicker
                    label="Start Date"
                    InputLabelProps={{ shrink: true }}
                    InputProps={{
                      disableUnderline: true,
                    }}
                    inputFormat="dd/MM/yyyy"
                    value={startDate ?? currentDate}
                    onChange={(e) => {
                      handleData(e, "startDate");
                    }}
                    // minDate={createdDate}
                    maxDate={currentDate}
                    renderInput={(params) => (
                      <TextField
                        sx={{ maxWidth: "150px" }}
                        variant="outlined"
                        size="small"
                        {...params}
                        inputProps={{
                          ...params.inputProps,
                          placeholder: "Start date",
                        }}
                      />
                    )}
                  />
                </LocalizationProvider>
              </Grid>
              <Grid item xs={3.2}>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DatePicker
                    label="End Date"
                    InputLabelProps={{ shrink: true }}
                    InputProps={{
                      disableUnderline: true,
                    }}
                    inputFormat="dd/MM/yyyy"
                    value={endDate ?? currentDate}
                    onChange={(e) => {
                      handleData(e, "endDate");
                    }}
                    minDate={startDate}
                    maxDate={currentDate}
                    renderInput={(params) => (
                      <TextField
                        sx={{ maxWidth: "150px" }}
                        variant="outlined"
                        size="small"
                        {...params}
                        inputProps={{
                          ...params.inputProps,
                          placeholder: "Start date",
                        }}
                      />
                    )}
                  />
                </LocalizationProvider>
              </Grid>
              <Grid item xs={2}>
                <Button
                  variant="contained"
                  size="medium"
                  onClick={handleScreenshotDownload}
                  style={{
                    color: "#fff",
                    backgroundColor: "#044a70",
                    border: `1px solid ${"#ddd"}`,
                    "&:hover": {
                      backgroundColor: "#fff",
                      color: "white",
                    },
                  }}
                  startIcon={<FiDownload />}
                >
                  Export
                </Button>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        <div
          style={{
            marginTop: "20px",
            height: "400px",
            width: "100%",
            border: "2px solid #dddd",
            borderRadius: "8px",
            paddingTop: "20px",
            boxShadow: "0px 3px 0px 10px #fff",
          }}
        >
          {loading ? (
            <></>
          ) : graphData && graphData.length > 0 ? (
            <ResponsiveContainer as="div" width="100%" height="100%">
              <LineChart
                width={2000}
                height={300}
                data={graphData}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="dateTime"
                  height={60}
                  tick={<CustomXAxisTick />}
                />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="value" stroke="#ff0000" />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <Grid
              container
              sx={{
                height: "50vh",
                borderRadius: "8px",
              }}
              justifyContent={"center"}
              alignItems={"center"}
            >
              <h3> No sensor data available for this device.</h3>
            </Grid>
          )}
        </div>{" "}
      </Grid>
    </>
  );
};

export default Example;
