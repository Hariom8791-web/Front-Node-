import React, { useState, useEffect, useRef } from "react";
import {
  Grid,
  Breadcrumbs,
  Typography,
  Container,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  TextField,
  Autocomplete,
  TablePagination,
  TableSortLabel,
  InputLabel,
  MenuItem,
  FormControl,
  Select,
  CircularProgress,
  IconButton,
  InputAdornment,
} from "@mui/material";
import ClearIcon from "@mui/icons-material/Clear";
import { IoClose } from "react-icons/io5";

import dayjs from "dayjs";
import { saveAs } from "file-saver";
import { AiOutlineSearch } from "react-icons/ai";

import { FiDownload } from "react-icons/fi";
import Papa from "papaparse";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";

import DeleteDialog from "../DeleteAlarm";
import NodataFound from "../../../../assets/img/nodatafound.png";
import axiosInstance from "../../../../api/axiosInstance";
import Analytics from "./Ananlytics";
// pagination

export default function Alarm() {
  const [alarm, setAlarm] = useState(null);
  const [orderBy, setOrderBy] = useState("");
  const [order, setOrder] = useState("asc");
  const [loadingDevice, setLoadingDevice] = useState(false);
  const tableContainerRef = useRef();

  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [startDate, setStartDate] = useState();
  const [endDate, setEndDate] = useState();
  const [searchTerm, setSearchTerm] = useState(null);
  const handleSearchClose = () => {
    setSearchTerm("");
  };
  const [filterValue, setFilterValue] = useState({
    sites: null,
    device: null,
    sensor: null,
  });
  const [resFilterData, setResFilterData] = useState({
    respSites: null,
    respDevice: null,
    respSensor: null,
  });

  const siteId = filterValue?.sites?._id;
  const filterDeviceId = filterValue?.device?._id;
  const sensorName = filterValue?.sensor?._id;

  const sortValue = order === "asc" ? -1 : 1;
  const currentDate = dayjs().toDate();
  const handleRequestSort = (event, key) => {
    const isAsc = orderBy === key && order === "asc";
    const newOrder = orderBy === key ? (isAsc ? "desc" : "asc") : "desc";
    setOrder(newOrder);
    setOrderBy(key);
  };

  const handleClearSite = () => {
    setFilterValue((prevState) => ({
      ...prevState,
      sites: null,
      device: null,
      sensor: null,
    }));
  };

  const handleClearDevice = () => {
    setFilterValue((prevState) => ({
      ...prevState,
      device: null,
      sensor: null,
    }));
  };
  const handleClearSensor = () => {
    setFilterValue((prevState) => ({
      ...prevState,
      sensor: null,
    }));
  };
  const handleFiterSelection = (event, value, field) => {
    setFilterValue((prevState) => ({
      ...prevState,
      [field]: value,
    }));
  };

  const handleData = (data, datatype) => {
    if (datatype == "startDate") {
      setStartDate(data);
    } else if (datatype == "endDate") {
      setEndDate(data);
    }
  };
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
  };

  const params = {
    deviceId: filterDeviceId,
    search: searchTerm ? searchTerm : null,
    startDate: dayjs(startDate ? startDate : currentDate)
      .startOf("day")
      .format("YYYY-MM-DD"),
    endDate: dayjs(endDate ? endDate : currentDate)
      .endOf("day")
      .format("YYYY-MM-DD"),
    sensorName: sensorName ? sensorName : null,
    page: page + 1,
    limit: rowsPerPage,
    sortType: sortValue,
    sortBy: orderBy ? orderBy : "createdAt",
  };

  useEffect(() => {
    getAllSites();
  }, []);

  useEffect(() => {
    if (siteId) {
      getAllDeviceBySiteId();
    }
  }, [siteId]);
  useEffect(() => {
    if (siteId && filterDeviceId) {
      getAllSensorBySiteDeviceId();
    }
  }, [siteId, filterDeviceId]);

  useEffect(() => {
    if (searchTerm?.length > 0) {
      getAllAlarm();
    } else if (
      page ||
      rowsPerPage ||
      startDate ||
      endDate ||
      sensorName ||
      filterDeviceId ||
      orderBy ||
      sortValue
    ) {
      getAllAlarm();
    }
  }, [
    page,
    rowsPerPage,
    startDate,
    filterDeviceId,
    endDate,
    sensorName,
    searchTerm,
    orderBy,
    sortValue,
  ]);

  const getAllSites = async () => {
    try {
      const response = await axiosInstance.get(
        `api/site/searchSite?searchQuery`
      );
      setResFilterData((prevData) => ({
        ...prevData,
        respSites: response.data.msg,
      }));
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const getAllDeviceBySiteId = async () => {
    try {
      setLoadingDevice(true);
      const response = await axiosInstance.get(
        `/api/device/getdeviceListbysiteId/${siteId}`
      );
      setResFilterData((prevData) => ({
        ...prevData,
        respDevice: response.data.msg,
      }));
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoadingDevice(false);
    }
  };

  const getAllSensorBySiteDeviceId = async () => {
    try {
      setLoadingDevice(true);
      const response = await axiosInstance.get(
        `/api/site/getSiteOrDeviceOrSensor/?siteId=${siteId}&deviceId=${filterDeviceId}`
      );
      const newDevices = response.data?.data;
      setResFilterData((prevData) => ({
        ...prevData,
        respSensor: newDevices,
      }));
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoadingDevice(false);
    }
  };
  const getAllAlarm = async () => {
    try {
      const response = await axiosInstance.get(`/api/alarm/getAlarmData`, {
        params,
      });
      if (response.data) {
        setAlarm(response.data);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  useEffect(() => {
    const intervalId = setInterval(() => {
      if (
        page ||
        rowsPerPage ||
        startDate ||
        endDate ||
        sensorName ||
        filterDeviceId ||
        orderBy ||
        sortValue
      ) {
        getAllAlarm();
      }
    }, 10000);
    return () => clearInterval(intervalId);
  }, [
    page,
    rowsPerPage,
    startDate,
    filterDeviceId,
    endDate,
    sensorName,
    searchTerm,
    orderBy,
    sortValue,
  ]);

  const handleExport = () => {
    const modifiedData = alarm?.data?.map((row) => ({
      "Site ID": row?.deviceId?.siteId?.uid,
      "Site Name": row?.deviceId?.siteId?.siteName,
      "Device UID": row?.deviceId?.nodeUid,
      "Device Name": row?.deviceId?.deviceName,
      "Sensor Name": row.SensorName,
      "Threshold Value": row.thresholdValue,
      "Alarm Value": row.alarmValue,
      Time: dayjs(row?.createdAt).format("h:mm A"),
      Date: dayjs(row?.createdAt).format("DD-MM-YYYY"),
    }));
    const csvData = [];
    const tableHeading = "Alarm Report";
    csvData.push([tableHeading]);
    const headerRow = Object.keys(modifiedData[0]);
    csvData.push(headerRow);

    modifiedData.forEach((row) => {
      const rowData = headerRow.map((key) => row[key]);
      csvData.push(rowData);
    });
    const csvString = Papa.unparse(csvData);
    const blob = new Blob([csvString], { type: "text/csv;charset=utf-8" });
    saveAs(blob, "Alarm_Report.csv");
  };

  useEffect(() => {
    if (tableContainerRef && tableContainerRef.current) {
      const tableContainer = tableContainerRef.current;
      // Store the current scroll position
      const scrollPosition = tableContainer.scrollTop;
      // After loading data, restore the scroll position
      tableContainer.scrollTop = scrollPosition;
    }
  }, [page, rowsPerPage, tableContainerRef]); // Add other dependencies if needed

  return (
    <>
      <Grid container direction="row" className="mt-8">
        <Grid container mt={3}>
          <Analytics />
        </Grid>{" "}
        <Grid
          container
          mt={3}
          direction="row"
          alignItems="center"
          justifyContent={"space-between"}
        >
          <Grid item xs={5}>
            <Grid container spacing={2}>
              <Grid item xs={4}>
                <Autocomplete
                  className="autocompletestyle"
                  disablePortal
                  id="combo-box-demo"
                  options={resFilterData?.respSites}
                  getOptionLabel={(option) => option.siteName}
                  value={filterValue?.sites}
                  onChange={(event, value) =>
                    handleFiterSelection(event, value, "sites")
                  }
                  clearIcon={<ClearIcon onClick={handleClearSite} />}
                  getOptionSelected={(option, value) =>
                    option.siteName === value
                  }
                  renderInput={(params) => (
                    <TextField {...params} label="All Site" />
                  )}
                />
              </Grid>
              <Grid item md={4}>
                <Autocomplete
                  className="autocompletestyle"
                  disablePortal
                  id="combo-box-demo-device"
                  options={resFilterData?.respDevice}
                  disabled={!resFilterData.respDevice}
                  getOptionLabel={(option) =>
                    option.deviceName || "Unknown Device"
                  }
                  value={filterValue?.device}
                  onChange={(event, value) =>
                    handleFiterSelection(event, value, "device")
                  }
                  clearIcon={<ClearIcon onClick={handleClearDevice} />}
                  getOptionSelected={(option, value) =>
                    option.deviceName === value
                  }
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      disabled={!resFilterData.respDevice}
                      label="All Devices"
                    />
                  )}
                />
              </Grid>
              <Grid item md={4}>
                <Autocomplete
                  className="autocompletestyle"
                  disablePortal
                  id="combo-box-demo-sensor"
                  options={resFilterData?.respSensor}
                  disabled={!resFilterData.respSensor}
                  getOptionLabel={(option) => option?._id || "Unknown Device"}
                  value={filterValue?.sensor}
                  onChange={(event, value) =>
                    handleFiterSelection(event, value, "sensor")
                  }
                  clearIcon={<ClearIcon onClick={handleClearSensor} />}
                  getOptionSelected={(option, value) => option?._id === value}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      disabled={!resFilterData.respSensor}
                      label="All Sensor"
                    />
                  )}
                />
              </Grid>
            </Grid>
          </Grid>{" "}
          <Grid item xs={5.5}>
            <Grid container justifyContent={"flex-end"}>
              <Grid item xs={3}>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DatePicker
                    label="Start Date"
                    InputLabelProps={{ shrink: true }}
                    InputProps={{
                      disableUnderline: true,
                    }}
                    inputFormat="dd/MM/yyyy"
                    value={startDate ?? currentDate}
                    onChange={(e) => {
                      handleData(e, "startDate");
                    }}
                    // minDate={createdDate}
                    maxDate={currentDate}
                    renderInput={(params) => (
                      <TextField
                        sx={{ maxWidth: "150px" }}
                        variant="outlined"
                        size="small"
                        {...params}
                        inputProps={{
                          ...params.inputProps,
                          placeholder: "Start date",
                        }}
                      />
                    )}
                  />
                </LocalizationProvider>
              </Grid>
              <Grid item xs={3.2}>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DatePicker
                    label="End Date"
                    InputLabelProps={{ shrink: true }}
                    InputProps={{
                      disableUnderline: true,
                    }}
                    inputFormat="dd/MM/yyyy"
                    value={endDate ?? currentDate}
                    onChange={(e) => {
                      handleData(e, "endDate");
                    }}
                    minDate={startDate}
                    maxDate={currentDate}
                    renderInput={(params) => (
                      <TextField
                        sx={{ maxWidth: "150px" }}
                        variant="outlined"
                        size="small"
                        {...params}
                        inputProps={{
                          ...params.inputProps,
                          placeholder: "Start date",
                        }}
                      />
                    )}
                  />
                </LocalizationProvider>
              </Grid>
              <Grid item xs={2.2}>
                <Button
                  variant="contained"
                  size="medium"
                  onClick={handleExport}
                  style={{
                    color: "#fff",
                    backgroundColor: "#044a70",
                    border: `1px solid ${"#ddd"}`,
                    "&:hover": {
                      backgroundColor: "#fff",
                      color: "white",
                    },
                  }}
                  startIcon={<FiDownload />}
                >
                  Export
                </Button>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        <Grid
          mt={3}
          container
          direction="row"
          alignItems="center"
          justifyContent={"space-between"}
        >
          <Typography variant="subtitle" pt={2}>
            Showing {alarm?.data?.length} of {alarm?.lengthData} Alarm
          </Typography>
          <Grid item>
            <TextField
              size="small"
              className="search-input"
              placeholder="Search  UID or Name"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              sx={{
                "& .MuiOutlinedInput-root": { borderRadius: 4 },
              }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <AiOutlineSearch fontSize="large" />
                  </InputAdornment>
                ),
                endAdornment: searchTerm?.length > 0 && (
                  <InputAdornment position="end">
                    <IoClose
                      fontSize="large"
                      className="cursor"
                      onClick={handleSearchClose}
                    />
                  </InputAdornment>
                ),
              }}
            />
          </Grid>
        </Grid>
        <Grid container className="mt-24">
          {alarm?.data.length > 0 ? (
            <TableContainer component={Paper}>
              <Table aria-label="simple table" ref={tableContainerRef}>
                <TableHead>
                  <TableRow>
                    <TableCell align="center" className="subheading-grey600">
                      <TableSortLabel
                        active={orderBy === "siteId"}
                        direction={orderBy === "siteId" ? order : "asc"}
                        onClick={(event) => handleRequestSort(event, "siteId")}
                      >
                        Site ID
                      </TableSortLabel>
                    </TableCell>
                    <TableCell align="center" className="subheading-grey600">
                      <TableSortLabel
                        active={orderBy === "siteName"}
                        direction={orderBy === "siteName" ? order : "asc"}
                        onClick={(event) =>
                          handleRequestSort(event, "siteName")
                        }
                      >
                        Site Name
                      </TableSortLabel>
                    </TableCell>

                    <TableCell align="center" className="subheading-grey600">
                      <TableSortLabel
                        active={orderBy === "nodeUid"}
                        direction={orderBy === "nodeUid" ? order : "asc"}
                        onClick={(event) => handleRequestSort(event, "nodeUid")}
                      >
                        Device UID{" "}
                      </TableSortLabel>
                    </TableCell>
                    <TableCell align="center" className="subheading-grey600">
                      <TableSortLabel
                        active={orderBy === "deviceName"}
                        direction={orderBy === "deviceName" ? order : "asc"}
                        onClick={(event) =>
                          handleRequestSort(event, "deviceName")
                        }
                      >
                        Device Name{" "}
                      </TableSortLabel>
                    </TableCell>
                    <TableCell align="center" className="subheading-grey600">
                      <TableSortLabel
                        active={orderBy === "SensorName"}
                        direction={orderBy === "SensorName" ? order : "asc"}
                        onClick={(event) =>
                          handleRequestSort(event, "SensorName")
                        }
                      >
                        Sensor Name{" "}
                      </TableSortLabel>
                    </TableCell>
                    <TableCell align="center" className="subheading-grey600">
                      <TableSortLabel
                        active={orderBy === "thresholdValue"}
                        direction={orderBy === "thresholdValue" ? order : "asc"}
                        onClick={(event) =>
                          handleRequestSort(event, "thresholdValue")
                        }
                      >
                        Threshold Value{" "}
                      </TableSortLabel>
                    </TableCell>
                    <TableCell align="center" className="subheading-grey600">
                      <TableSortLabel
                        active={orderBy === "alarmValue"}
                        direction={orderBy === "alarmValue" ? order : "asc"}
                        onClick={(event) =>
                          handleRequestSort(event, "alarmValue")
                        }
                      >
                        Alarm Value{" "}
                      </TableSortLabel>
                    </TableCell>
                    <TableCell align="center" className="subheading-grey600">
                      Time
                    </TableCell>
                    <TableCell align="center" className="subheading-grey600">
                      <TableSortLabel
                        active={orderBy === "createdAt"}
                        direction={orderBy === "createdAt" ? order : "asc"}
                        onClick={(event) =>
                          handleRequestSort(event, "createdAt")
                        }
                      >
                        Date{" "}
                      </TableSortLabel>
                    </TableCell>
                    <TableCell align="center" className="subheading-grey600">
                      Action
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {alarm?.data?.map((row) => (
                    <TableRow key={row.name}>
                      <TableCell
                        align="center"
                        className="p-0"
                        component="th"
                        scope="row"
                      >
                        {row?.deviceId?.siteId?.uid}
                      </TableCell>
                      <TableCell
                        padding={0}
                        align="center"
                        className="heading-black "
                      >
                        {row?.deviceId?.siteId?.siteName}
                      </TableCell>
                      <TableCell align="center" className="heading-black ">
                        {row?.deviceId?.nodeUid}
                      </TableCell>
                      <TableCell align="center" className="heading-black ">
                        {row?.deviceId?.deviceName}
                      </TableCell>{" "}
                      <TableCell align="center" className="heading-black ">
                        {row.SensorName}
                      </TableCell>{" "}
                      <TableCell align="center">{row.thresholdValue}</TableCell>{" "}
                      <TableCell align="center" className="red-typo">
                        {row.alarmValue}
                      </TableCell>{" "}
                      <TableCell align="center" className="heading-black ">
                        {dayjs(row?.createdAt).format("h:mm A")}
                      </TableCell>
                      <TableCell align="center" className="heading-black ">
                        {dayjs(row?.createdAt).format("DD-MM-YYYY")}
                      </TableCell>{" "}
                      <TableCell align="center">
                        <Grid
                          container
                          justifyContent="space-evenly"
                          direction="row"
                        >
                          <DeleteDialog
                            alarmID={row._id}
                            getnumberOfAlarm={getAllAlarm}
                          />
                        </Grid>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          ) : (
            <Grid container>
              <Grid item className="mt-32 width100">
                <Typography align="center">
                  <img src={NodataFound} />{" "}
                </Typography>
              </Grid>
              <Typography
                className="heading-black width100 mt-42"
                align="center"
              >
                No Alarm found!
              </Typography>
            </Grid>
          )}
        </Grid>
        <Grid container justifyContent={"flex-end"}>
          <TablePagination
            rowsPerPageOptions={[
              10,
              25,
              50,
              100,
              200,
              { label: "All", value: 10000 },
            ]}
            component="div"
            count={alarm?.lengthData}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />{" "}
        </Grid>
      </Grid>
    </>
  );
}
